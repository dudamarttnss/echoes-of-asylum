using UnityEngine;

public class EnemyFollowPlayer : MonoBehaviour
{
    public float velocidade = 3f;
    public float distanciaDetectarPlayer = 5f;  
    public float distanciaMinimaAtaque = 1.5f;   
    public float tempoPerseguindoMax = 30f;
    // public Raio raio;

    private Transform player;
    private Rigidbody2D rb;
    private AplicadorDano ataque;
    

    private bool perseguindo = false;
    private float tempoPerseguindo = 0f;

    void Start()
    {
        GameObject jogadorObj = GameObject.FindGameObjectWithTag("Player");
        if (jogadorObj != null)
        {
            player = jogadorObj.transform;
        }

        rb = GetComponent<Rigidbody2D>();
        ataque = GetComponent<AplicadorDano>();
    }

    void Update()
    {
        if (player == null) return;

        float distancia = Vector2.Distance(transform.position, player.position);

        // Inicia perseguição se o player estiver dentro da distância de detecção
        if (!perseguindo && distancia <= distanciaDetectarPlayer)
        {
            perseguindo = true;
            tempoPerseguindo = 0f; 
        }

    
        if (perseguindo)
        {
            tempoPerseguindo += Time.deltaTime;

            // Persegue enquanto o tempo não acabar
            if (tempoPerseguindo <= tempoPerseguindoMax)
            {
                if (distancia > distanciaMinimaAtaque)
                {
                    Vector2 direcao = (player.position - transform.position).normalized;
                    rb.MovePosition(rb.position + direcao * velocidade * Time.deltaTime);
                }

              
                if (player.position.x > transform.position.x)
                    transform.localScale = new Vector3(1, 1, 1);
                else
                    transform.localScale = new Vector3(-1, 1, 1);
            }
            else
            {
               
                perseguindo = false;
                Debug.Log("Inimigo parou de perseguir o player.");
            }
        }
    }

    // public void LancarRaios() {

    //     Vector2 direcao = (jogador.position - transform.position).normalized;
    //     float angulo = Vector2.Angle(direcao) //pesquisar como transformar direção em angulo em graus.
    //     int quantidadeRaio = 4;
    //     float distanciaEntreRaios = 15;
    //     for(int i = 0; i < quantidadeRaio; i++) 
    //     {
    //         float anguloRaio = distanciaEntreRaios*i;
    //         Vector2 direcaoRaio = Vector2.AngleToVector(anguloRaio);  //pesquisar como transformar angulo (ex: 180º em direcao (vector2))
    //         Raio raioInstancia = Instantiate(raio); //avaliar
    //         raioInstancia.transform.right = direcaoRaio;

    //     }
    // }
    
}


